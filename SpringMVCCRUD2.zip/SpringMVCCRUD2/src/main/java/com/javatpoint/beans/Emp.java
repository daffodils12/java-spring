package com.javatpoint.beans;  


import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class Emp {  
private int empno;  
private String ename,job,dept,mgr,hiredate;  
private float sal,comm;  


public int getEmpno() {
	return empno;
}
public void setEmpno(int empno) {
	this.empno = empno;
}
public String getDept() {
	return dept;
}
public void setDept(String dept) {
	this.dept = dept;
}
public String getMgr() {
	return mgr;
}
public void setMgr(String mgr) {
	this.mgr = mgr;
}
public String getHiredate() {
	return hiredate;
}
public void setHiredate(String hiredate) {
	this.hiredate = hiredate;
}
public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}
public String getJob() {
	return job;
}
public void setJob(String job) {
	this.job = job;
}
public float getSal() {
	return sal;
}
public void setSal(float sal) {
	this.sal = sal;
}
public float getComm() {
	return comm;
}
public void setComm(float comm) {
	this.comm = comm;
}
public Emp() {
	
}

public Emp(int empno, String ename, String job, String dept,
        String mgr, String hiredate, float sal, float comm) {
    this.empno = empno;
    this.ename = ename;
    this.job = job;
    this.dept = dept;
    this.mgr = mgr;
    this.hiredate = hiredate;
    this.sal = sal;
    this.comm = comm;
}

@Override
public String toString() {
  return "Emp [empno=" + empno + ", empname=" + ename + "]";
}	



}  