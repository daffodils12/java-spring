package com.javatpoint.beans;

public class Dept {
	private int deptno;
	private String deptname,loc;
	
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	public String getDeptname() {
		return deptname;
	}
	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	
	  @Override
	  public String toString() {
	    return "Dept [deptno=" + deptno + ", deptname=" + deptname + "]";
	  }		

}
