package com.javatpoint.beans;

public class Manager {
	private int mgrno;
	private String mgrname;
	
	public Manager() {
	}	
	
	public Manager(int empno, String ename) {
		// TODO Auto-generated constructor stub
		mgrno=this.mgrno;
		mgrname=this.mgrname;
	}
	public int getMgrno() {
		return mgrno;
	}
	public void setMgrno(int mgrno) {
		this.mgrno = mgrno;
	}
	public String getMgrname() {
		return mgrname;
	}
	public void setMgrname(String mgrname) {
		this.mgrname = mgrname;
	}
	
	  @Override
	  public String toString() {
	    return "Manager [mgrno=" + mgrno + ", mgrname=" + mgrname + "]";
	  }	
}
