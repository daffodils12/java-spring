/**
 * 
 */
package com.javatpoint.controllers;

import javax.validation.Valid;  
import org.springframework.stereotype.Controller;  
import org.springframework.ui.Model;  
import org.springframework.validation.BindingResult;  
import org.springframework.web.bind.annotation.ModelAttribute;  
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.javatpoint.beans.User;  


@Controller  
public class UserController {  
  
    @RequestMapping(value="/beforeViewemp",method = RequestMethod.GET)  
    public String display(Model m1)  
    {  
        m1.addAttribute("user", new User());  
        return "beforeViewemp";          
    }  
    @RequestMapping(value="helloAgain",method = RequestMethod.POST)  
    public String submitForm( @Valid @ModelAttribute("user") User e, BindingResult br)  
    {  
        if(br.hasErrors())  
        {  
            return "final";  
        }  
        else  
        {  
        return "redirect:/viewemp/1";  
        }  
    }  
}  