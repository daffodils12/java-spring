package com.javatpoint.controllers;  

import java.util.List;
import java.util.Map;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCreationHelper;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;  
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.javatpoint.beans.Emp;
import com.javatpoint.beans.Manager;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.text.BaseColor;

import com.javatpoint.beans.Dept;
import com.javatpoint.dao.EmpDao;
import com.javatpoint.dao.EmpDao2;
import com.javatpoint.dao.DeptDao;

import com.javatpoint.dao.DownloadCSV; 
import com.javatpoint.dao.DownloadPDF;
import com.javatpoint.dao.DownloadPDF2;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.*;
import java.nio.ByteBuffer; 
import java.util.*; 
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.sql.Connection;
import java.sql.DriverManager;


@Controller  
public class EmpController  {  
	@Autowired  
	//will inject daos from xml file
    EmpDao dao; 

	String ename,job,hiredate,dept,mgr;
	int empno;
	float sal, comm;	
	
    /*It displays a form to input data, here "command" is a reserved request attribute 
     *which is used to display object data into form 
     */  
	private Logger logger = Logger.getLogger(EmpController.class);
	
    @RequestMapping("/empform")  
    public String addEmp(Model m2){  
    	m2.addAttribute("command", new Emp());
        List<Dept> dept=dao.getDepts();  
        List<Manager> mgr=dao.getManagers();
        
        m2.addAttribute("dept",dept);          
        m2.addAttribute("mgr",mgr);   

        logger.info("This is an info log entry for ShowForm");
    	return "empform"; 
    }  
    /*It saves object into database. The @ModelAttribute puts request data 
     *  into model object. You need to mention RequestMethod.POST method  
     *  because default request is GET*/  
    @RequestMapping(value="/save",method = RequestMethod.POST)  
    public String save(@ModelAttribute("emp") Emp emp){  
        dao.save(emp);  
        return "redirect:/viewemp/1";//will redirect to viewemp request mapping  
    }  
    /* It provides list of employees in model object */  
    @RequestMapping(value="/viewemp/{pageid}") 
    public String viewemp(@PathVariable int pageid, Model m2){  
    	logger.info("This is an info log entry for viewemp");
        int total=5,pagenr=0;    
        if(pageid==1 || pageid==0){ pageid=1; pagenr=1;}    
        else{    
            pageid=(pageid-1)*total+1; 
            pagenr=Math.round(pageid/5)+1;
        }   

        //System.out.println("Pageid :"+pageid);
        System.out.println("pagenr :"+pagenr);
        //System.out.println("Total :"+total);
        List<Emp> list=dao.getEmployeesByPage(pageid,total);  
        m2.addAttribute("list",list);
        return "viewemp";  
    }  
    
    @RequestMapping(value="/editemp/{id}")  
    public String edit(@PathVariable int id, Model m2){  
    	logger.info("This is an info log entry for edit");
    	String mgrName,deptName;
        Emp emp=dao.getEmpById(id);
        mgrName=emp.getMgr();
        deptName=emp.getDept();

        m2.addAttribute("command",emp);
        List<Dept> dept=dao.getDepts();  
        List<Manager> mgr=dao.getManagers();
        
        m2.addAttribute("dept",dept);          
        m2.addAttribute("mgr",mgr);

        List<Manager> options1 = dao.getManagers();
        List<Dept> options2 = dao.getDepts();

        m2.addAttribute("options1", options1);
        m2.addAttribute("mgrselectedValue", mgrName);
        
        m2.addAttribute("options2", options2);
        m2.addAttribute("deptselectedValue", deptName);        

        return "empeditform";  
    }      
    /* It updates model object. */  
    @RequestMapping(value="/editsave",method = RequestMethod.POST)  
    public String editsave(@ModelAttribute("emp") Emp emp){  
        dao.update(emp);  
        return "redirect:/viewemp/1";  
    }  
    /* It deletes record for the given id in URL and redirects to /viewemp */  
    @RequestMapping(value="/deleteemp/{id}",method = RequestMethod.GET)  
    public String delete(@PathVariable int id){  
        dao.delete(id);  
        return "redirect:/viewemp/1";  
    }   
    
    @RequestMapping(value="/downloadcsv",method = RequestMethod.GET)
    public ResponseEntity<byte[]> downloadcsv(HttpServletResponse response) throws IOException {
    	logger.info("In downloadcsv");
    	byte[] excelBytes= new byte[10];
    	String status="";
    	
    	DownloadCSV dldcsv = new DownloadCSV();
    	status=dldcsv.Download(dao);
    	
    	if (status.equals("Success")) {
	        String sourceFile = "Employees.csv";
	        try {
	            FileInputStream inputStream = new FileInputStream(sourceFile);
	            String disposition = "attachment; fileName=Employees.csv";
	            response.setContentType("text/csv");
	            response.setHeader("Content-Disposition", disposition);
	            response.setHeader("content-Length", String.valueOf(stream(inputStream, response.getOutputStream())));
	
	        } catch (IOException e) {
	            logger.error("Error occurred while downloading file {}",e);
	        }        	
    	}          	   	

        // Return the Excel file as a byte array with appropriate headers
        return new ResponseEntity<>(excelBytes, HttpStatus.OK);    	
    }
    
    private long stream(InputStream input, OutputStream output) throws IOException {

        try (ReadableByteChannel inputChannel = Channels.newChannel(input); WritableByteChannel outputChannel = Channels.newChannel(output)) {
            ByteBuffer buffer = ByteBuffer.allocate(10240);
            long size = 0;

            while (inputChannel.read(buffer) != -1) {
                buffer.flip();
                size += outputChannel.write(buffer);
                buffer.clear();
            }
            return size;
        }
    }    

    @GetMapping("/downloadXLS")
    public ResponseEntity<byte[]> downloadXLS() throws IOException {    	
    	byte[] excelBytes= new byte[10];
    	try {
	    	logger.info("In downloadXLS");	   	
	    	List<Emp> emps=dao.getEmps();
	        List<Dept> depts=dao.getDepts();

	    	Workbook wb = new HSSFWorkbook();		   	        
	    	HSSFCreationHelper createHelper = (HSSFCreationHelper) wb.getCreationHelper();		    		    
		    
			logger.info("after createHelper");
			EmpDao2 eDao2 = new EmpDao2();
			eDao2.WriteWorkBook(emps,wb);
			DeptDao dDao = new DeptDao();
			dDao.WriteWorkBook(depts,wb);			
			
	        // Write workbook content to byte array
	        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	        wb.write(outputStream);
	        wb.close();
	        excelBytes = outputStream.toByteArray();

			logger.info("writing to file");
			
    	} catch(Exception e) {
    		e.printStackTrace();
    	}

        // Set HTTP headers for file download
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", "Employees.xls");

        // Return the Excel file as a byte array with appropriate headers
        return new ResponseEntity<>(excelBytes, headers, HttpStatus.OK);
    }        
    
    @RequestMapping(value="/downloadpdf2",method = RequestMethod.GET)
    public ResponseEntity<byte[]> downloadpdf2() throws IOException {
    	logger.info("In downloadpdf2");
		List<Emp> emps = dao.getEmps();	
		byte[] pdfBytes = new byte[10];
		
		
		try {
	        // Write workbook content to byte array
	        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			DownloadPDF2 dPDF2 = new DownloadPDF2();
			
		    // Step-1 Creating a PdfDocument object 
		    PdfDocument pdfDoc  = new PdfDocument(new PdfWriter(outputStream)); 
		    
		    // Step-2 Creating a Document object 
		    Document doc = new Document(pdfDoc);				    
		    
		    doc = dPDF2.WritePDF(emps,outputStream,doc);
	        pdfBytes = outputStream.toByteArray();		       

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
        // Set HTTP headers for file download
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", "Employees.pdf");

        // Return the Excel file as a byte array with appropriate headers
        return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);   	
    	
    }                
}  