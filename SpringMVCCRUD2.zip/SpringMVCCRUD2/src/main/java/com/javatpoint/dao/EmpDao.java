package com.javatpoint.dao;  

import java.sql.ResultSet;  
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List; 
import java.util.ArrayList; 
import java.util.Comparator;
import java.text.SimpleDateFormat;
import org.springframework.jdbc.core.BeanPropertyRowMapper;  
import org.springframework.jdbc.core.JdbcTemplate;  
import org.springframework.jdbc.core.RowMapper;  
import com.javatpoint.beans.Emp;
import com.javatpoint.beans.Manager;  
import com.javatpoint.beans.Dept;
  
public class EmpDao {  
JdbcTemplate template;  

  
public void setTemplate(JdbcTemplate template) {  
    this.template = template;  
}  
public int save(Emp p){  
    SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
    //String formattedDate = formatter.format(p.gethireDate());
    
    //String sql="insert into Emp(empno,ename,sal,job,comm,deptno,mgr) values(emp_seq.nextval,"+"'"+p.getEname()+"',"+p.getSal()+",'"+p.getJob()+"',"+p.getComm()+",to_Date('"+formattedDate+"','MM/DD/YYYY')',"+p.getDeptno()+p.getMgr()+")";
    String sql="insert into Emp(empno,ename,sal,job,comm,deptno,mgr,hiredate) values(emp_seq.nextval,"+"initcap('"+p.getEname()+"'),"+p.getSal()+",initcap('"+p.getJob()+"'),"+p.getComm()+","+p.getDept()+","+p.getMgr()+","+"to_Date('"+p.getHiredate()+"','MM/DD/YYYY')"+")";
    System.out.println(sql);
    return template.update(sql);  
}  
public int update(Emp p){ 
    //SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
    //String formattedDate = formatter.format(p.getHiredate());    
    	
    //String sql="update Emp set ename='"+p.getEname()+"', sal="+p.getSal()+",job='"+p.getJob()+"', comm="+p.getComm()+", hiredate=to_Date('"+formattedDate+"','MM/DD/YYYY')'"+", "+"deptno="+p.getDeptno()+" where empno="+p.getEmpno()+"";
    String sql="update Emp set ename=initcap('"+p.getEname()+"'), sal="+p.getSal()+",job=initcap('"+p.getJob()+"'), comm="+p.getComm()+", "+"deptno="+p.getDept()+", mgr="+p.getMgr()+", hiredate=to_Date('"+p.getHiredate()+"','MM/DD/YYYY')"+" where empno="+p.getEmpno()+"";
    System.out.println(sql);
    return template.update(sql);  
}  
public int delete(int id){  
    String sql="delete from Emp where empno="+id+"";  
    return template.update(sql);  
} 
public Emp getEmpById(int id){  
	String sql=" select empno,ename,sal,job,nvl(comm,0) comm,dname,mgr_name,hiredate from emp_mgr_vw e where e.empno=?";
	System.out.println("in getEmpById"+sql);
	//return template.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<Emp>(Emp.class));  
	return template.queryForObject(sql, new Object[]{id},new EmpRowMapper());
}  
public List<Emp> getEmployeesByPage(int pageid,int total){ 
	String sql;
	if (pageid==1) {
		sql="select empno,ename,sal,job,comm,dname,mgr_name,hiredate from emp_mgr_vw order by ename fetch first 5 rows only"; 
	} else {
		sql="select empno,ename,sal,job,comm,dname,mgr_name,hiredate from emp_mgr_vw order by ename  OFFSET "+((pageid-1))+" ROWS FETCH NEXT 5 ROWS ONLY";   
	}    

	System.out.println(sql);  
    return template.query(sql,new RowMapper<Emp>(){    
        public Emp mapRow(ResultSet rs, int row) throws SQLException {    
            Emp e=new Emp();    
            e.setEmpno(rs.getInt(1));  
            e.setEname(rs.getString(2));  
            e.setSal(rs.getFloat(3));  
            e.setJob(rs.getString(4)); 
            Float comm = rs.getFloat(5);
            if (rs.wasNull()) {
            	comm=0.0F;
            }
            e.setComm(comm);
            //e.setComm(rs.getFloat(5));       
            //e.sethireDate(rs.getDate(6)); 
            e.setDept(rs.getString(6));           
            e.setMgr(rs.getString(7));
            e.setHiredate(rs.getString(8));
            return e;  
        }    
    });    
}  


public List<Manager> getManagers() {        
	final List<Manager> listManager = new ArrayList();
	
    String sql = "select empno as mgrno,ename as mgrname from emp where job in ('Manager','President')";
    System.out.println(sql);
    return template.query(sql,new RowMapper<Manager>() {    
        public Manager mapRow(ResultSet rs, int row) throws SQLException {   
        
        	Manager mgr=new Manager(); 
        	//System.out.println(rs.getInt("mgrno"));
        	//System.out.println(rs.getString("mgrname"));
        	
        	mgr.setMgrno(rs.getInt("mgrno"));
        	mgr.setMgrname(rs.getString("mgrname"));
        	listManager.add(mgr);	
        	
			return mgr;
        }        
    });  

}

public List<Dept> getDepts() {
    final List<Dept> listdepts = new ArrayList();
    
    String sql = "select deptno,dname as deptname,loc from dept";
    System.out.println(sql);
    return template.query(sql,new RowMapper<Dept>() {    
        public Dept mapRow(ResultSet rs, int row) throws SQLException {   
        
        	Dept depts=new Dept(); 
        	//System.out.println(rs.getInt("deptno"));
        	//System.out.println(rs.getString("deptname"));
        	
        	depts.setDeptno(rs.getInt("deptno"));
        	depts.setDeptname(rs.getString("deptname"));
        	depts.setLoc(rs.getString("loc"));
        	listdepts.add(depts);	
        	
			return depts;
        }
        
    });  
}
    
public List<Emp> getEmps() {
	final List<Emp> listemps = new ArrayList();
	
	String sql = "select empno,ename,sal,job,comm,dname,mgr_name,hiredate from emp_mgr_vw order by ename";
	
    return template.query(sql,new RowMapper<Emp>() {    
        public Emp mapRow(ResultSet rs, int row) throws SQLException {   
        
        	Emp emps=new Emp(); 
       	
        	emps.setEmpno(rs.getInt("empno"));
        	emps.setEname(rs.getString("ename"));
        	emps.setSal(rs.getFloat("sal"));
        	emps.setJob(rs.getString("job"));
        	emps.setComm(rs.getFloat("comm"));
        	emps.setDept(rs.getString("dname"));
        	emps.setMgr(rs.getString("mgr_name"));
        	emps.setHiredate(rs.getString("hiredate"));
        	listemps.add(emps);	
        	
			return emps;
        }
        
    });  
}

}