package com.javatpoint.dao;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import com.javatpoint.beans.Emp;

public class EmpRowMapper implements RowMapper<Emp> {

    public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {

        Emp emp = new Emp();
        emp.setEmpno(rs.getInt("empno"));
        emp.setEname(rs.getString("ename"));
        emp.setSal(rs.getFloat("sal"));
        emp.setJob(rs.getString("job"));        
        emp.setComm(rs.getFloat("comm"));
        emp.setDept(rs.getString("dname"));
        emp.setMgr(rs.getString("mgr_name"));
        emp.setHiredate(rs.getString("hiredate"));
        

        return emp;

    }
}

