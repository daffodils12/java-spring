package com.javatpoint.dao;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCreationHelper;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;


import com.javatpoint.beans.Dept;
import com.javatpoint.beans.Emp;

import org.apache.poi.hssf.usermodel.HSSFRow;

public class DeptDao {
	
	public DeptDao() {
		
	}
	
	public void WriteWorkBook(List<Dept> listDepts,Workbook wb) {
		Sheet sheet2 = wb.createSheet("Department List");

		CellStyle style = wb.createCellStyle();
		style.setFillForegroundColor(IndexedColors.ORANGE.getIndex());
		style.setFillPattern(FillPatternType.SOLID_FOREGROUND);				
		Font font = wb.createFont();
		font.setFontName("Arial");
		style.setFont(font);	

		HSSFRow row = (HSSFRow) sheet2.createRow(0);
		
		row.createCell(0).setCellValue("Deptno");
		row.getCell(0).setCellStyle(style);
		
		row.createCell(1).setCellValue("Dept Name");
		row.getCell(1).setCellStyle(style);				
	
		row.createCell(2).setCellValue("Location");
		row.getCell(2).setCellStyle(style);	
		
		// create data rows
		int rowCount = 1;
		
		for (Dept aDept : listDepts) {
			HSSFRow aRow = (HSSFRow) sheet2.createRow(rowCount++);
			aRow.createCell(0).setCellValue(aDept.getDeptno());
			aRow.createCell(1).setCellValue(aDept.getDeptname());
			aRow.createCell(2).setCellValue(aDept.getLoc());
		}				
	
	// Display message on console for successful
	// execution of program
	System.out.println(
	    "Sheets Has been Created successfully");
	
	// Finding number of Sheets present in Workbook
	int numberOfSheets = wb.getNumberOfSheets();
	System.out.println("Total Number of Sheets: "
	                   + numberOfSheets);        
	

	}


}
