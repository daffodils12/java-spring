package com.javatpoint.dao;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import com.opencsv.CSVWriter;

import com.javatpoint.beans.Emp;

import org.apache.log4j.Logger;


public class DownloadCSV {
		
	private Logger logger = Logger.getLogger(DownloadCSV.class);	
	

	
	public String Download(EmpDao dao)  throws IOException {
		logger.info("In Download method of DownloadCSV");
		File file = new File("Employees.csv"); 
		
		String empData;
		String ename,job,hiredate,dept,mgr;
		int empno;
		float sal, comm;	
		String[] empArray;
		try {
			
	        // create FileWriter object with file as parameter 
	        FileWriter outputfile = new FileWriter(file);     		
	            
	        logger.info("before header downloadcsv");
	        String[] header = { "Id", "Name", "Salary", "Designation", "Comm", "Dept", "HireDate", "Manager" };
	        logger.info("after header downloadcsv");
	        
	        //using custom delimiter and quote character
	        CSVWriter csvWriter;
			csvWriter = new CSVWriter(outputfile);
			csvWriter.writeNext(header);
			csvWriter.flush();
			logger.info("after csvWriter downloadcsv");
			
			List<Emp> emps = dao.getEmps();	
			
			Iterator<Emp> it = emps.iterator();
			//logger.info("after Iterator ");
			while (it.hasNext()) {
				Emp emp = it.next();	
				
				empno=emp.getEmpno();
				ename=emp.getEname();
				job=emp.getJob();
				sal=emp.getSal();
				comm=emp.getComm();
				hiredate=emp.getHiredate();
				dept=emp.getDept();
				mgr=emp.getMgr();
								
				empData=empno+","+ename+","+job+","+sal+","+comm+","+hiredate+","+dept+","+mgr;				
				empArray  = empData.split(",");
				//logger.info("empData "+empData);
				csvWriter.writeNext(empArray);
				csvWriter.flush();		
		        				
			}			
			csvWriter.close();
			
			//System.out.println(writer);
	        			
	        
		} catch (Exception ex) {
			System.out.println("Exception :"+ex);
			logger.info("Exception :"+ex);
			return "failed";
		}
		
		return "Success";
  }	
 
}
