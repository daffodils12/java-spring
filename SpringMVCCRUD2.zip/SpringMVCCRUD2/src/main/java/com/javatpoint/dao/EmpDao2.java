package com.javatpoint.dao;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCreationHelper;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;


import com.javatpoint.beans.Emp;
import org.apache.poi.hssf.usermodel.HSSFRow;

public class EmpDao2 {
	
	public EmpDao2() {
		
	}
	
	public void WriteWorkBook(List<Emp> listEmps,Workbook wb) {
		Sheet sheet1 = wb.createSheet("Employees List");		

		HSSFRow row = (HSSFRow) sheet1.createRow(0);		
		CellStyle style = wb.createCellStyle();
		style.setFillForegroundColor(IndexedColors.ORANGE.getIndex());
		style.setFillPattern(FillPatternType.SOLID_FOREGROUND);		
		Font font = wb.createFont();
		font.setFontName("Arial");
		style.setFont(font);			
		
		row = (HSSFRow) sheet1.createRow(0);
		
		row.createCell(0).setCellValue("Empno");
		row.getCell(0).setCellStyle(style);
		
		row.createCell(1).setCellValue("Employee Name");
		row.getCell(1).setCellStyle(style);
		
		row.createCell(2).setCellValue("Sal");
		row.getCell(2).setCellStyle(style);
		
		row.createCell(3).setCellValue("Job");
		row.getCell(3).setCellStyle(style);
		
		row.createCell(4).setCellValue("Comm");
		row.getCell(4).setCellStyle(style);
		
		row.createCell(5).setCellValue("DeptName");
		row.getCell(5).setCellStyle(style);
		
		row.createCell(6).setCellValue("Manager");
		row.getCell(6).setCellStyle(style);
		
		row.createCell(7).setCellValue("Hiredate");
		row.getCell(7).setCellStyle(style);		
		
		// create data rows
		int rowCount = 1;
		
		for (Emp aEmp : listEmps) {
			HSSFRow aRow = (HSSFRow) sheet1.createRow(rowCount++);
			aRow.createCell(0).setCellValue(aEmp.getEmpno());
			aRow.createCell(1).setCellValue(aEmp.getEname());
			aRow.createCell(2).setCellValue(aEmp.getSal());
			aRow.createCell(3).setCellValue(aEmp.getJob());
			aRow.createCell(4).setCellValue(aEmp.getComm());
			aRow.createCell(5).setCellValue(aEmp.getDept());
			aRow.createCell(6).setCellValue(aEmp.getMgr());
			aRow.createCell(7).setCellValue(aEmp.getHiredate());
		}					
	   
		
	}


}