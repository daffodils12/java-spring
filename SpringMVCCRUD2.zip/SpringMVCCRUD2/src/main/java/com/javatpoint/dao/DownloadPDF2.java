package com.javatpoint.dao;

//Adding table in a pdf using java 
import com.itextpdf.kernel.pdf.PdfDocument; 
import com.itextpdf.kernel.pdf.PdfWriter; 

import com.itextpdf.layout.Document; 
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Font;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.PageSize;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Iterator;


import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.io.source.ByteArrayOutputStream;
import com.itextpdf.kernel.colors.Color;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.layout.element.Table;


import com.javatpoint.beans.Emp;
import com.javatpoint.controllers.EmpController;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;

public class DownloadPDF2 {
	String empno,sal, comm, empData,ename,job,hiredate,dept,mgr,textLine;
	String[] listText;
	int i=0;
	
	public DownloadPDF2() {
		
	}	
	
	public Document WritePDF(List<Emp> emps,java.io.ByteArrayOutputStream outputStream,Document doc) throws IOException {	
		
		Paragraph paragraph = new Paragraph("Employees List");		 
		doc.add(paragraph);	
		
        
	    // Step-3 Creating a table 
	    Table table = new Table(8);
	    table.setBackgroundColor(ColorConstants.LIGHT_GRAY);
	    
	    table.addCell("Id");
	    table.addCell("Name");
	    table.addCell("Sal");
	    table.addCell("Job");
	    table.addCell("Comm");
	    table.addCell("Dept");
	    table.addCell("Manager");
	    table.addCell("HireDate");
	    	    
		for (Emp aEmp : emps) {
			empno = Integer.toString(aEmp.getEmpno());
			sal = Float.toString(aEmp.getSal());
			comm = Float.toString(aEmp.getComm());
			hiredate = aEmp.getHiredate();
			if (aEmp.getMgr() != null) {
				mgr=aEmp.getMgr();
			} else {
				mgr="";
			}
			if (aEmp.getHiredate() != null) {
				hiredate=aEmp.getHiredate();
			} else {
				hiredate="";
			}
			
		    table.addCell(empno);
		    table.addCell(aEmp.getEname());
		    table.addCell(sal);
		    table.addCell(aEmp.getJob());
		    table.addCell(comm);
		    table.addCell(aEmp.getDept());
		    table.addCell(mgr);
		    table.addCell(hiredate);	    
		}	    	
	
	    // Step-6 Adding Table to document 
	    doc.add(table); 	    
	
	    // Step-7 Closing the document 
	    doc.close(); 
	    System.out.println("Table created successfully.."); 
	    return doc;      				
	}		      

 
}
