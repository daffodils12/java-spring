package com.javatpoint.dao;

import java.io.File; 
import java.io.IOException;
import java.util.List;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.apache.pdfbox.pdmodel.PDDocument; 
import org.apache.pdfbox.pdmodel.PDPage; 
import org.apache.pdfbox.pdmodel.PDPageContentStream; 
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.graphics.PDFontSetting;

import com.javatpoint.beans.Emp;
import com.javatpoint.controllers.EmpController;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;

import org.apache.log4j.Logger;

public class DownloadPDF {
	
	public DownloadPDF() {
		
	}
	String empData,ename,job,hiredate,dept,mgr,textLine;
	int empno;
	float sal, comm;
	String[] listText;
	int i=0;
	
	public void WritePDF(List<Emp> emps) throws IOException {
	
			
		   	PDDocument document = new PDDocument();
		       
		      //Retrieving the pages of the document 
		   	  PDPage page= new PDPage();
		   	  document.addPage(page);
		      PDPageContentStream contentStream = new PDPageContentStream(document, page);
		      
		      //Begin the Content stream 
		      contentStream.beginText(); 		      		   
		       
		      //Setting the font to the Content stream  
		      contentStream.setFont(getFont(document),12);

		      //Setting the position for the line 
		      contentStream.newLineAtOffset(25, 700);

		      //String text = "This is the sample document and we are adding content to it.";
		      
				Iterator<Emp> it = emps.iterator();
				while (it.hasNext()) {
					Emp emp = it.next();	
					
					empno=emp.getEmpno();
					ename=emp.getEname();
					job=emp.getJob();
					sal=emp.getSal();
					comm=emp.getComm();
					hiredate=emp.getHiredate();
					dept=emp.getDept();
					mgr=emp.getMgr();
					
					empData=empno+","+ename+","+job+","+sal+","+comm+","+hiredate+","+dept+","+mgr+" ";

			        // break big text using my endof line flag
			        listText = empData.split("\n");	
			        for (String textLine : listText) {
						contentStream.setLeading(14.5f);  // set the size of the newline to something reasonable
						contentStream.showText(textLine);
						contentStream.newLine();							        	
			        }	
				}	

		      //Ending the content stream
		      contentStream.endText();

		      //Closing the content stream
		      contentStream.close();

		      //Saving the document
		      document.save(new File("C:/jagan/java/Employees.pdf"));

		      //Closing the document
		      document.close();
		      
				
		}		      

	    private static PDType0Font getFont(PDDocument pdDocument) throws IOException {
	        PDType0Font font = PDType0Font.load(pdDocument, new File("c:/jagan/java/ARIAL.ttf"));
	        return font;
	    }	   
}
