drop table tutorial;

CREATE TABLE TUTORIAL 
(
  TUTORIAL_ID INTEGER PRIMARY KEY
, DESCRIPTION VARCHAR2(30) 
, LEVELS INTEGER 
, TITLE VARCHAR2(30) 
);

insert into tutorial(tutorial_id,Description,levels,title) values(1,'Tut#1',2,'BezKoder Tut#1');
insert into tutorial(tutorial_id,Description,levels,title) values(2,'Tut#2',6,'BezKoder Tut#2');
insert into tutorial(tutorial_id,Description,levels,title) values(3,'Tut#3',8,'BezKoder Tut#3');
insert into tutorial(tutorial_id,Description,levels,title) values(4,'Tut#4',10,'BezKoder Tut#4');
insert into tutorial(tutorial_id,Description,levels,title) values(5,'Tut#5',7,'BezKoder Tut#5');
insert into tutorial(tutorial_id,Description,levels,title) values(6,'Tut#6',9,'BezKoder Tut#6');
insert into tutorial(tutorial_id,Description,levels,title) values(7,'Tut#7',8,'BezKoder Tut#7');
insert into tutorial(tutorial_id,Description,levels,title) values(8,'Tut#8',5,'BezKoder Tut#8');
insert into tutorial(tutorial_id,Description,levels,title) values(9,'Tut#9',1,'BezKoder Tut#9');
insert into tutorial(tutorial_id,Description,levels,title) values(10,'Tut#10',3,'BezKoder Tut#10');
insert into tutorial(tutorial_id,Description,levels,title) values(11,'Tut#11',8,'BezKoder Tut#11');
insert into tutorial(tutorial_id,Description,levels,title) values(12,'Tut#12',4,'BezKoder Tut#12');
insert into tutorial(tutorial_id,Description,levels,title) values(13,'Tut#13',7,'BezKoder Tut#13');
insert into tutorial(tutorial_id,Description,levels,title) values(14,'Tut#14',1,'BezKoder Tut#14');
insert into tutorial(tutorial_id,Description,levels,title) values(15,'Tut#15',6,'BezKoder Tut#15');
insert into tutorial(tutorial_id,Description,levels,title) values(16,'Tut#16',4,'BezKoder Tut#16');
insert into tutorial(tutorial_id,Description,levels,title) values(17,'Tut#17',8,'BezKoder Tut#17');
insert into tutorial(tutorial_id,Description,levels,title) values(18,'Tut#18',6,'BezKoder Tut#18');
insert into tutorial(tutorial_id,Description,levels,title) values(19,'Tut#19',9,'BezKoder Tut#19');
insert into tutorial(tutorial_id,Description,levels,title) values(20,'Tut#20',4,'BezKoder Tut#20');
insert into tutorial(tutorial_id,Description,levels,title) values(21,'Tut#21',6,'BezKoder Tut#21');
insert into tutorial(tutorial_id,Description,levels,title) values(22,'Tut#22',5,'BezKoder Tut#22');
insert into tutorial(tutorial_id,Description,levels,title) values(23,'Tut#23',3,'BezKoder Tut#23');
insert into tutorial(tutorial_id,Description,levels,title) values(24,'Tut#24',1,'BezKoder Tut#24');
insert into tutorial(tutorial_id,Description,levels,title) values(25,'Tut#25',9,'BezKoder Tut#25');
insert into tutorial(tutorial_id,Description,levels,title) values(26,'Tut#26',5,'BezKoder Tut#26');
insert into tutorial(tutorial_id,Description,levels,title) values(27,'Tut#27',7,'BezKoder Tut#27');
insert into tutorial(tutorial_id,Description,levels,title) values(28,'Tut#28',4,'BezKoder Tut#28');
insert into tutorial(tutorial_id,Description,levels,title) values(29,'Tut#29',7,'BezKoder Tut#29');
insert into tutorial(tutorial_id,Description,levels,title) values(30,'Tut#30',6,'BezKoder Tut#30');
insert into tutorial(tutorial_id,Description,levels,title) values(31,'Tut#31',1,'BezKoder Tut#31');
insert into tutorial(tutorial_id,Description,levels,title) values(32,'Tut#32',2,'BezKoder Tut#32');
insert into tutorial(tutorial_id,Description,levels,title) values(33,'Tut#33',8,'BezKoder Tut#33');
insert into tutorial(tutorial_id,Description,levels,title) values(34,'Tut#34',5,'BezKoder Tut#34');
insert into tutorial(tutorial_id,Description,levels,title) values(35,'Tut#35',6,'BezKoder Tut#35');
commit;

 DROP SEQUENCE "SCOTT"."TUTORIAL_ID_SEQ";
 CREATE SEQUENCE  "SCOTT"."TUTORIAL_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 
 INCREMENT BY 1 START WITH 35 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


-- Create the trigger
CREATE OR REPLACE TRIGGER tutorial_bir
BEFORE INSERT ON tutorial
FOR EACH ROW
BEGIN
    SELECT tutorial_id_seq.NEXTVAL
    INTO   :NEW.tutorial_id
    FROM   DUAL;
END;
/
