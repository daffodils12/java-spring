package com.bezkoder.spring.thymeleaf.controller;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.bezkoder.spring.thymeleaf.entity.Tutorial;
import com.bezkoder.spring.thymeleaf.repository.TutorialRepository;

@Controller
public class TutorialController {

  @Autowired
  private TutorialRepository tutorialRepository;

  @GetMapping("/tutorials")
  public String getAll(Model model, @Param("keyword") String keyword) {
    try {
      List<Tutorial> tutorials = new ArrayList<Tutorial>();

      if (keyword == null) {
        tutorialRepository.findAll().forEach(tutorials::add);
      } else {
        tutorialRepository.findByTitleContainingIgnoreCase(keyword).forEach(tutorials::add);
        model.addAttribute("keyword", keyword);
      }

      model.addAttribute("tutorials", tutorials);
    } catch (Exception e) {
      model.addAttribute("message", e.getMessage());
    }

    return "tutorials";
  }

  @GetMapping("/tutorials/new")
  public String addTutorial(Model model) {
    Tutorial tutorials = new Tutorial();

    model.addAttribute("tutorial", tutorials);
    model.addAttribute("pageTitle", "Create new Tutorial");

    return "tutorial_form";
  }

  @PostMapping("/tutorials/save")
  public String saveTutorial(Tutorial tutorials, RedirectAttributes redirectAttributes) {
    try {
      
      System.out.println("tutorial_id :"+tutorials.gettutorial_id());
      System.out.println("Title :"+tutorials.getTitle());
      System.out.println("Desc :"+tutorials.getDescription());
      System.out.println("Levels :"+tutorials.getLevels());
      //System.out.println("Published :"+tutorials.getPublished());     
      tutorialRepository.save(tutorials);

      redirectAttributes.addFlashAttribute("message", "The Tutorial has been saved successfully!");
    } catch (Exception e) {
      redirectAttributes.addAttribute("message", e.getMessage());
    }

    return "redirect:/tutorials";
  }

  @GetMapping("/tutorials/edit/{tutorial_id}")
  public String editTutorial(@PathVariable("tutorial_id") BigInteger tutorial_id, Model model, RedirectAttributes redirectAttributes) {
    try {
      Tutorial tutorials = tutorialRepository.findById(tutorial_id).get();      

      model.addAttribute("tutorial", tutorials);
      model.addAttribute("pageTitle", "Edit Tutorial (ID: " + tutorial_id + ")");      

      return "tutorial_form";
    } catch (Exception e) {
      redirectAttributes.addFlashAttribute("message", e.getMessage());

      return "redirect:/tutorials";
    }
  }

  @GetMapping("/tutorials/delete/{tutorial_id}")
  public String deleteTutorial(@PathVariable("tutorial_id") BigInteger tutorial_id, Model model, RedirectAttributes redirectAttributes) {
    try {
      System.out.println("deleteTutorial id :"+tutorial_id);
      tutorialRepository.deleteById(tutorial_id);

      redirectAttributes.addFlashAttribute("message", "The Tutorial with id=" + tutorial_id + " has been deleted successfully!");
    } catch (Exception e) {
      redirectAttributes.addFlashAttribute("message", e.getMessage());
    }

    return "redirect:/tutorials";
  }

  /*@GetMapping("/tutorials/edit/{id}/published/{status}")
  public String updateTutorialPublishedStatus(@PathVariable("id") BigInteger tutorial_id, @PathVariable("status") String published,
      Model model, RedirectAttributes redirectAttributes) {
    try {
      tutorialRepository.updatePublishedStatus(tutorial_id, published);   

      String status;
      if (published != null) {
    	  status = "published";
      } else {
    	  status = "disabled";
      }
      String message = "The Tutorial id=" + tutorial_id + " has been " + status;

      redirectAttributes.addFlashAttribute("message", message);
    } catch (Exception e) {
      redirectAttributes.addFlashAttribute("message", e.getMessage());
    }

    return "redirect:/tutorials";
 }*/
}
