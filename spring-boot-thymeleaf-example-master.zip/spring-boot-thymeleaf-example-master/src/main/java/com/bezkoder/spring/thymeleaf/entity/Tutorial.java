package com.bezkoder.spring.thymeleaf.entity;

import java.math.BigInteger;
import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "TUTORIAL")
public class Tutorial {  
  
  @Id 
  @Column(name = "TUTORIAL_ID", insertable = true, updatable = true)
  @GeneratedValue(generator = "incrementor")
  @GenericGenerator(name = "incrementor", strategy = "increment")
  public BigInteger tutorial_id; 

  @Column(length = 128, nullable = false)
  private String title;

  @Column(length = 256)
  private String description;

  @Column(name = "levels", columnDefinition = "NUMERIC(19,0)",nullable = false)
  private BigInteger levels;

  /*@Column(name = "published", columnDefinition = "CHAR(1)",nullable = false)
  private char published;
  */
	
  
  public Tutorial() {

  }

  public Tutorial(String title, String description, BigInteger levels, char published) {
    this.title = title;
    this.description = description;
    this.levels = levels;
    //this.published = published;
  }

  public BigInteger gettutorial_id() {
    return tutorial_id;
  }

  public void settutorial_id(BigInteger tutorial_id) {
    this.tutorial_id = tutorial_id;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public BigInteger getLevels() {
    return levels;
  }

  public void setLevels(BigInteger levels) {
    this.levels = levels;
  }

  /*public char getPublished() {
    return published;
  }

  public void setPublished(char published) {
    this.published = published;
  }*/

  @Override
  public String toString() {
    return "Tutorial [id=" + tutorial_id + ", title=" + title + ", description=" + description + ", levels=" + levels +"]";
  }

}
