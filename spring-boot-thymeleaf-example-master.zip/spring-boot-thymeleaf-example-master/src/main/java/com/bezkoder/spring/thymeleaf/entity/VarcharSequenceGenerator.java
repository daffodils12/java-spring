package com.bezkoder.spring.thymeleaf.entity;

import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.id.SequenceGenerator;

@SuppressWarnings("deprecation")
public class VarcharSequenceGenerator extends SequenceGenerator{

public Serializable generate(SessionImplementor arg0, Object arg1)
throws HibernateException {
Object sequenceResult = super.generate(arg0, arg1);
return sequenceResult == null ? null : sequenceResult.toString();
}


}
